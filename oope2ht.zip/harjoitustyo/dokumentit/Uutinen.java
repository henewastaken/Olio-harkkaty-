
package harjoitustyo.dokumentit;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
;

/**
 * Konkreettinen luokka uutisille.
 * 
 * <p> 
 * Olio-ohjelmoinnin perusteet II, kevät 2020
 * 
 * @version 0.1
 * @author Henry Andersson, henry.andersson@tuni.fi.
 * 
 */
public class Uutinen extends Dokumentti{
    /*
    * Attribuutit
    */
    
    /** Päivämäärän kertova attribuutti */
    private LocalDate päivämäärä;

    /*
    * Aksessorit
    */
    
    // Lukevat aksessorit
    public LocalDate päivämäärä() {
        return päivämäärä;
    }
    /*
    public String teksti () {
        return super.teksti();
    }

    public int tunniste () {
        return super.tunniste();
    }
    
    public String tulosta () {
        return Uutinen.this.päivämäärä() + teksti() + tunniste();
    }
    */
    // Asettavat aksessorit
    public void päivämäärä(LocalDate päiväys) throws IllegalArgumentException {
        if (päiväys == null) {
            throw new IllegalArgumentException(VIRHE);
        } else {
        päivämäärä = päiväys;
        }
    }
    /*
    public void tunniste (int tunnus) throws IllegalArgumentException{
        if (tunnus == 0 ) {
            throw new IllegalArgumentException(VIRHE);
        }
        super.tunniste(tunnus);
    }
    
    public void teksti (String sanoma) throws IllegalArgumentException{
        if (sanoma.isEmpty() || sanoma == null) {
            throw new IllegalArgumentException(VIRHE);
        }
        super.teksti(sanoma);
    }
    */

    /*
    * Rakentajat
    */
    public Uutinen(int tunnus, LocalDate päiväys, String kirjoitelma) throws IllegalArgumentException {
        super(tunnus, kirjoitelma);
        päivämäärä(päiväys);
    }
    
    /*
    * OBject-luokan metodien korvaukset
    */
    /**
    * Muodostaa dokumentin merkkijonoesityksen, joka koostuu tunnisteesta
    * erottimesta, päiväyksestä ja tekstistä.
    *
    * @return dokumentin merkkijonoesitys lisättynä päiväys.
    */
    @Override
    public String toString() {
        String muotoiltuPäiväys = päivämäärä.format(DateTimeFormatter.ofPattern("d.M.yyyy"));
        return tunniste() + EROTIN + muotoiltuPäiväys + EROTIN + teksti();
    }
}
